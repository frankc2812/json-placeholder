document.addEventListener('DOMContentLoaded', () => {
    const taskForm = document.getElementById('task-form');
    const taskInput = document.getElementById('new-task');
    const taskList = document.getElementById('task-list');

    taskForm.addEventListener('submit', addTask);

    function addTask(e) {
        e.preventDefault();
        const taskText = taskInput.value;

        const li = document.createElement('li');
        li.textContent = taskText;

        const completeBtn = document.createElement('button');
        completeBtn.textContent = '✔';
        completeBtn.classList.add('complete-btn');
        completeBtn.addEventListener('click', completeTask);

        const deleteBtn = document.createElement('button');
        deleteBtn.textContent = '✖';
        deleteBtn.addEventListener('click', deleteTask);

        li.appendChild(completeBtn);
        li.appendChild(deleteBtn);

        taskList.appendChild(li);

        taskInput.value = '';
    }

    function completeTask(e) {
        const taskItem = e.target.parentElement;
        taskItem.classList.toggle('completed');
    }

    function deleteTask(e) {
        const taskItem = e.target.parentElement;
        taskList.removeChild(taskItem);
    }
});
